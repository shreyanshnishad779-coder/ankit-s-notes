# NoteNest — student notes website

## Start locally
1. Install Node.js 20+.
2. Open a terminal in this folder and run `npm install`.
3. Copy `.env.example` to `.env` and replace `ADMIN_PASSWORD` with a strong secret.
4. Run `npm start` and visit http://localhost:3000.

Use **Admin upload** to publish notes. Visitors can search, filter and download without signing in.

## Put it online
Deploy to a Node.js host with a **persistent disk/volume**. Set `ADMIN_PASSWORD` in the host environment settings; set `PORT` if your host requires it. Preserve the `uploads/` folder and `notes.json` across deployments/restarts. A host with ephemeral storage will lose uploads; use a persistent volume or adapt storage to an object-storage provider. Use HTTPS in production. Never publish your `.env` file.

Supported uploads: PDF, DOC, DOCX, PPT, PPTX, XLS, XLSX and TXT, up to 20 MB. For public production use, consider adding file scanning, backups, admin accounts and cloud storage.
